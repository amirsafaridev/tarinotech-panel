<?php

/*
|--------------------------------------------------------------------------
| Authentication Language Lines
|--------------------------------------------------------------------------
|
| The following language lines are used during authentication for various
| messages that we need to display to the user. You are free to modify
| these language lines according to your application's requirements.
|
*/

return [
    'forget' => [
        'email' => 'کد برای شما ارسال شد',
        'sms' => 'کد برای شما ارسال شد',
    ],
];
