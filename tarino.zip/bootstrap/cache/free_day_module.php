<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\FreeDay\\app\\Providers\\FreeDayServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\FreeDay\\app\\Providers\\FreeDayServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);