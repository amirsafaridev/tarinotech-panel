<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Payment\\app\\Providers\\PaymentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Payment\\app\\Providers\\PaymentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);