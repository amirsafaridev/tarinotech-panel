<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Project\\app\\Providers\\ProjectServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Project\\app\\Providers\\ProjectServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);