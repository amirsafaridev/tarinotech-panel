<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Personnel\\app\\Providers\\PersonnelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Personnel\\app\\Providers\\PersonnelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);