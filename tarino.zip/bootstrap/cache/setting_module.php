<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Setting\\app\\Providers\\SettingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Setting\\app\\Providers\\SettingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);