<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ajax\\app\\Providers\\AjaxServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ajax\\app\\Providers\\AjaxServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);