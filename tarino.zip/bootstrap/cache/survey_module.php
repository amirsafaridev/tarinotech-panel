<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Survey\\app\\Providers\\SurveyServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Survey\\app\\Providers\\SurveyServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);