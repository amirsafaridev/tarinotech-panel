<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Admin\\app\\Providers\\AdminServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Admin\\app\\Providers\\AdminServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);