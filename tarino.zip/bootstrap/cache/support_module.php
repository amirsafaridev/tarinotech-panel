<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Support\\app\\Providers\\SupportServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Support\\app\\Providers\\SupportServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);