<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Stream\\app\\Providers\\StreamServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Stream\\app\\Providers\\StreamServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);