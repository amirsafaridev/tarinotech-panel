<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Report\\app\\Providers\\ReportServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Report\\app\\Providers\\ReportServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);