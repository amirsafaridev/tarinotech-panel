<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Log\\app\\Providers\\LogServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Log\\app\\Providers\\LogServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);