<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Role\\app\\Providers\\RoleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Role\\app\\Providers\\RoleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);