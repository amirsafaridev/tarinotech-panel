<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contract\\app\\Providers\\ContractServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contract\\app\\Providers\\ContractServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);