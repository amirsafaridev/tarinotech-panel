<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Package\\app\\Providers\\PackageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Package\\app\\Providers\\PackageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);