<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Factor\\app\\Providers\\FactorServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Factor\\app\\Providers\\FactorServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);