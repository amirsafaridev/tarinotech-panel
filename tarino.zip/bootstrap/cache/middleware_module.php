<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Middleware\\app\\Providers\\MiddlewareServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Middleware\\app\\Providers\\MiddlewareServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);