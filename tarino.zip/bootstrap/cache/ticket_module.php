<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ticket\\app\\Providers\\TicketServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ticket\\app\\Providers\\TicketServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);