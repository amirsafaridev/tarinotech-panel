<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Login\\app\\Providers\\LoginServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Login\\app\\Providers\\LoginServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);