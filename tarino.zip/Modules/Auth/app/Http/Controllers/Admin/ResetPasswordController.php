<?php

namespace Modules\Auth\app\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Auth;
use DB;
use Exception;
use Modules\Admin\app\Models\Admin;
use Modules\Auth\App\Http\Requests\Admin\Auth\ResetPasswordRequest;
use Modules\Auth\app\Models\OtpCode;

class ResetPasswordController extends Controller
{
    const INDEX_TITLE = 'پورتال تارینوتک - بازنشانی گذرواژه';

    public function __construct()
    {
        $this->middleware('admin.guest:admin');
    }

    public function index()
    {
        $title = self::INDEX_TITLE;

        return view('auth::admin.passwords.reset', compact('title'));
    }

    public function reset(ResetPasswordRequest $request)
    {
        try {
            $otp = OtpCode::query()
                ->with('user')
                ->where('code', $request->input('code'))
                ->where('expired_at', '>', now())
                ->first();

            if (! $otp) {
                return to_route('admin.password.reset')
                    ->with('error', trans('panel.auth.reset.otp.invalidate'));
            }

            DB::beginTransaction();

            /**
             * Update Admin Password Scenario
             *
             * @var Admin $admin
             */
            $admin = $otp->user;
            $this->adminPasswordUpdate($admin, $request->input('password'));

            DB::commit();

            Auth::guard('admin')->loginUsingId($otp->user_id);

            return redirect()->to(route('admin.dashboard.index'));
        } catch (Exception $exception) {
            DB::rollBack();
            report($exception);

            return to_route('admin.password.reset')
                ->with('error', trans('panel.auth.reset.error'));
        }
    }

    private function adminPasswordUpdate(Admin $admin, string $password)
    {
        $admin->update([
            'password' => bcrypt($password),
        ]);

        $admin->otpCodes()->delete();
    }
}
