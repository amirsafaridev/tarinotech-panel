<?php

return [
    'name' => 'Chat',
];
