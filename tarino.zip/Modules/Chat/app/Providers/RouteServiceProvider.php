<?php

namespace Modules\Chat\app\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The module namespace to assume when generating URLs to actions.
     */
    protected string $moduleNamespace = 'Modules\Chat\app\Http\Controllers';

    /**
     * Called before routes are registered.
     *
     * Register any model bindings or pattern based filters.
     */
    public function boot(): void
    {
        parent::boot();
    }

    /**
     * Define the routes for the application.
     */
    public function map(): void
    {
        $this->mapApiRoutes();

        $this->mapAdminRoutes();
    }

    /**
     * Define the "web" routes for the application.
     *
     * These routes all receive session state, CSRF protection, etc.
     */
    protected function mapAdminRoutes(): void
    {
        $prefix = config('routes.admin-prefix');
        Route::prefix($prefix.'/chat')
            ->namespace($this->moduleNamespace)
            ->middleware(['web', 'admin.auth', 'acl', 'admin.scope'])
            ->as('admin.chat.')
            ->group(module_path('Chat', '/routes/admin.php'));
    }

    /**
     * Define the "api" routes for the application.
     *
     * These routes are typically stateless.
     */
    protected function mapApiRoutes(): void
    {
        Route::prefix('api/v1/chat')
            ->middleware('api')
            ->namespace($this->moduleNamespace)
            ->group(module_path('Chat', '/routes/api.php'));
    }
}
