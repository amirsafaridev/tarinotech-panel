<?php

return [
    'name' => 'Content',
];
