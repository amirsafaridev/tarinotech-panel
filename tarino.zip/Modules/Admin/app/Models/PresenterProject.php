<?php

namespace Modules\Admin\app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PresenterProject extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $table = 'presenter_project';
}
