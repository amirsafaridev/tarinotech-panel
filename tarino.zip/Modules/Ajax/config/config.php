<?php

return [
    'name' => 'Ajax',
];
